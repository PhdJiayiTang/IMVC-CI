function [temp_S]=update_S2(lambda,num_view,temp_S,temp_oS,alpha,g)
%S{i} v x n, oS v x n, alpha, v x 1
for v=1:num_view
    other_view=setdiff(1:num_view,v);
    temp3=temp_S(other_view,:);
    temp_S(v,:)=max((alpha(v)*g+lambda*((1-alpha(v)*(num_view-2))*alpha(other_view)'*temp3+alpha(v)*sum(temp3,1)))/((1+lambda*(num_view-1))*alpha(v)^2+lambda),0);
    orgin=find(temp_oS(v,:)>0);
    temp_S(v,orgin)=temp_oS(v,orgin);
end
end