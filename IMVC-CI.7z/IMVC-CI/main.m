clear;
clc;
addpath('ClusteringMeasure', 'LRR', 'utils');
% addpath(genpath('gspbox-0.7.0/'));
% resultdir1 = 'Results/';
% resultdir2 = 'totalResults/';
resultdir1 = 'new_Results/';
resultdir2 = 'new_totalResults/';
% datadir='./data/';
% dataname={'MSRCV1_3v'};
% numdata = length(dataname); % number of the test datasets
numname = {'_Per0.1', '_Per0.2', '_Per0.3', '_Per0.4','_Per0.5', '_Per0.6', '_Per0.7', '_Per0.8', '_Per0.9', '_Per1'};
datadir='D:\Incomplete multi-view datasets\';
% ./data/';
% dataname = {'100Leaves','BBCSport','BDGP_fea',...
%     'buaaRnSp','Caltech101-7','Caltech101-all_fea',...
%     'Caltech256_fea_sort_sub','CCV','fmnist',...
%     'handwritten','Hdigit','HW',...
%     'Mfeat','MNIST_fea','MSRCV1_3v',...
%     'NGs','NUSWIDEOBJ','ORL_mtv',...
%     'prokaryotic','proteinFold','Reuters',...
%     'stl10_fea','SUNRGBD_fea','synthetic3d',...
%     'tinyimage','uci-digit','WebKB',...
%     'Wiki_fea','YoutubeFace_sel_fea','ALOI'};
dataname ={'100Leaves','ALOI','CCV','Hdigit','MSRCV1_3v','synthetic3d'};
% dataname = {'Incomplete_100Leaves','Incomplete_BBCSport','Incomplete_CiteSeer','Incomplete_ORL_mtv','Incomplete_UCI_Digits','Incomplete_ALOI-100'};
% rate=0.1:0.1:0.5;
numdata = length(dataname); % number of the test datasets
% numname = {''};
for idata = 1: length(dataname)
    ResBest = zeros(10, 8);
    ResStd = zeros(10, 8);
    % result = [Fscore Precision Recall nmi AR Entropy ACC Purity];
    %     for dataIndex = 1: 2: 9
    for dataIndex =9 : length(numname)%dataIndex = 1 : 1
        datafile = [datadir, cell2mat(dataname(idata)), cell2mat(numname(dataIndex)),'.mat'];
        %data preparation...
        load(datafile);
%         if strcmp(dataname{idata},'3sourceIncomplete')
            gt = truelabel{1};
%         end
        if size(data{1},2)~=length(gt)
            for iiii=1:length(data)
                data{iiii}=data{iiii}';
            end
        end
        cls_num = length(unique(gt));
        tic;
        if dataIndex<10
            [X1, O1, X2, O2] = DataPreparing(data, index);
        else
            X1=data;
            for ik=1:length(data)
                O1{ik}=eye(length(gt));
            end
        end
        
        time1 = toc;
        maxAcc = 0;
%         TempLambda1 = 0.0001;
%         TempLambda1=[0.0001,0.001, 0.01, 0.1, 0.5, 1];
%         TempLambda2=[25:5:50];
%         TempLambda2 = [5:2:25];
                TempLambda2 = 7;
                TempLambda1 = 1;
        ACC = zeros(length(TempLambda1), length(TempLambda2));
        NMI = zeros(length(TempLambda1), length(TempLambda2));
        Purity = zeros(length(TempLambda1), length(TempLambda2));
        OBJ=cell(length(TempLambda1), length(TempLambda2));
        idx = 1;
        for LambdaIndex1 = 1 : length(TempLambda1)
            lambda1 = TempLambda1(LambdaIndex1);
            for LambdaIndex2 = 1 : length(TempLambda2)
                lambda2 = TempLambda2(LambdaIndex2);
                disp([char(dataname(idata)),'_', char(numname(dataIndex)),'_', char(numname(dataIndex)), '-l1=', num2str(lambda1), '-l2=', num2str(lambda2)]);
                tic;
                [com_affinity,obj,S] = IMVC_CN_nonsymmetry_Par(X1, O1, gt, lambda2,lambda1);
                F = SpectralClustering(com_affinity, cls_num);
                time2 = toc;
                stream = RandStream.getGlobalStream;
                reset(stream);
                MAXiter = 1000; % Maximum number of iterations for KMeans
                REPlic = 20; % Number of replications for KMeans
                tic;
                res = zeros(20, 8);
                for rep = 1 : 20
                    pY = kmeans(F, cls_num, 'maxiter', MAXiter, 'replicates', REPlic, 'emptyaction', 'singleton');
                    res(rep, : ) = Clustering8Measure(gt, pY);
                end
                time3 = toc;
                runtime(idx) = time1 + time2 + time3 / 20;
                disp(['runtime:', num2str(runtime(idx))])
                idx = idx + 1;
                tempResBest(dataIndex, : ) = mean(res);
                tempResStd(dataIndex, : ) = std(res);
                ACC(LambdaIndex1, LambdaIndex2) = tempResBest(dataIndex, 7);
                NMI(LambdaIndex1, LambdaIndex2) = tempResBest(dataIndex, 4);
                Purity(LambdaIndex1, LambdaIndex2) = tempResBest(dataIndex, 8);
                OBJ{LambdaIndex1, LambdaIndex2} = obj;
                save([resultdir1, char(dataname(idata)), '_', char(numname(dataIndex)), ...
                    '-acc=', num2str(tempResBest(dataIndex, 7)), ...
                    '-l1=', num2str(lambda1), '-l2=', num2str(lambda2) , '_result.mat'], ...
                    'tempResBest', 'tempResStd');
                for tempIndex = 1 : size(tempResBest,2)
                    if tempResBest(dataIndex, tempIndex) > ResBest(dataIndex, tempIndex)
                            newS = S;
                            newG = com_affinity;
                            newHistory = obj;
                        ResBest(dataIndex, tempIndex) = tempResBest(dataIndex, tempIndex);
                        ResStd(dataIndex, tempIndex) = tempResStd(dataIndex, tempIndex);
                    end
                end
            end
        end
        aRuntime = mean(runtime);
        PResBest = ResBest(dataIndex, : );
        PResStd = ResStd(dataIndex, : );
        save([resultdir2, char(dataname(idata)), char(numname(dataIndex)), '_ACC_', num2str(max(ACC( : ))), '_result.mat'], 'ACC', 'NMI', 'Purity', 'aRuntime', ...
            'newS', 'newG',  'newHistory',  'PResBest', 'PResStd', 'gt');   
    end
    save([resultdir2, char(dataname(idata)), char(numname(dataIndex)), '_result.mat'], 'ResBest', 'ResStd');
end