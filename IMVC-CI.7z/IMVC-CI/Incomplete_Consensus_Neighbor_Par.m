function [G,obj,S]=Incomplete_Consensus_Neighbor_Par(S,P,num_sample,num_view,lambda)
G=zeros(num_sample);
A=(num_view-2)*ones(num_view)+eye(num_view);
origin_S=S;
obj=[];
for iter=1:30
    parfor i=1:num_sample
        temp =full(S{i}*S{i}');
        alpha=zeros(num_view,1);
        if iter==1
            G(i,:)=(ones(1,num_view)/num_view)*S{i}/num_view;
            noempty=find(P(i,:)>0);
            Error=S{i}*G(i,:)';
            Error=Error(noempty,1);
            solution = diag(diag(temp(noempty,noempty)))\Error;
            alpha(noempty) = EProjSimplex_new(solution);      
        else
            solution=pinv(lambda*(A.*temp)+diag(diag(temp)))*(S{i}*G(i,:)'+lambda*(temp*ones(num_view,1)-diag(temp)));
            alpha = EProjSimplex_new(solution);
        end
        G(i,:)=alpha'*S{i}/num_view;
        obj1(i)=cal_obj_Par(G(i,:),S{i},alpha,num_view); 
        [Si]=update_S2(lambda,num_view,S{i},origin_S{i},alpha,G(i,:));
        S{i}=sparse(Si);
    end
    obj(iter)=sum(obj1);
    if iter>2 && abs((obj(iter-1)-obj(iter))/(obj(iter-1)))<1e-4 
        break;
    end
end

end