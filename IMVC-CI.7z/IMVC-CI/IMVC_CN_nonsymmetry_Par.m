function [com_affinity,obj,S,Affinity] = IMVC_CN_nonsymmetry_Par(X, Po, truth, knn, lambda, type)


if nargin < 7
    type = 'euclidean';
end
num_view = length(X);  % number of views
idx = cell(1, num_view);
num_sample = length(truth);
Affinity = zeros(num_sample,num_sample, num_view);
affinity_sample = cell(num_sample,1);
P=zeros(num_sample,num_view);
for i=1:num_view
    temp=Po{i};
    try
        s = sprintf('kernel%d.mat', i); % try to read the weight matrix (if saved previously)
        load(s);
    catch
        W = make_affinity_matrix(X{i}', type);
%         save(s, 'W')  % weight matrix may be saved for repeating experiments
    end
    if knn ~= 0  % not using fully connected graph
        [W, idx{i}] = kNN_nonsymmetry_row(W, knn);
%         W=W';
    end
    affinity = temp'*W*temp;
    Affinity(:,:,i)=(affinity + affinity')/2;
    for j=1:num_sample
        affinity_sample{j,1}(i,:)=sparse(affinity(j,:));
    end
    P(:,i)=sum(temp);
end
% P=sparse(P);
[com_affinity,obj,S]=Incomplete_Consensus_Neighbor_Par(affinity_sample,P,num_sample,num_view,lambda);
com_affinity=(com_affinity'+com_affinity)/2;
% com_affinity= kNN(com_affinity, knn);
% F = SpectralClustering(com_a, cls_num);
% MAXiter = 100; % Maximum number of iterations for KMeans
% REPlic = 20; % Number of replications for KMeans
% res2 = zeros(20, 8);
% for rep = 1 : 20
%     pY = kmeans(F, cls_num, 'maxiter', MAXiter, 'replicates', REPlic, 'emptyaction', 'singleton');
%     res2(rep, : ) = Clustering8Measure(truth, pY);
% end
end

