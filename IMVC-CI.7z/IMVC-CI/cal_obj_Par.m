function [obj]= cal_obj_Par(g,S,alpha,num_view)

% if size(alpha,1)==num_view
%     obj=norm(g-alpha'*S,2)^2;
% else
%     obj=norm(g-alpha*S,2)^2;
% end
record=zeros(num_view,1);
for i = 1 : num_view
    record(i)=norm(g-alpha(i)*S(i,:),2)^2;%+lambda*norm(S(:,i)-old_S(:,setdiff(1:num_view,i))*alpha(setdiff(1:num_view,i)),2)^2;
end
obj=sum(record);